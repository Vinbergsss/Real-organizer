// Kad lapa pilnībā ielādēta, izsauc funkciju loadNotes
document.addEventListener("DOMContentLoaded", () => {
    loadNotes();
});

// Funkcija, kas ielādē piezīmes no servera un attēlo tās
function loadNotes() {
    // Atrodam konteineru, kurā tiks parādītas piezīmes
    const container = document.getElementById("notes-container");
    if (!container) return;  // Ja konteineris nav atrasts, pārtraucam funkcijas darbību

    // Rāda ielādes ziņojumu lietotājam
    container.innerHTML = '<div class="loading">Loading notes...</div>';

    // Saņem šodienas datumu formātā YYYY-MM-DD
    const today = new Date().toISOString().split("T")[0];

    // Nosūta pieprasījumu serverim, lai iegūtu piezīmes konkrētajam datumam
    fetch(`../../includes/get_notes.php?date=${today}`)
        .then(response => {
            // Ja servera atbilde nav veiksmīga, izmestu kļūdu
            if (!response.ok) throw new Error(`Server error: ${response.status}`);
            return response.json(); // Pārveido atbildi JSON formātā
        })
        .then(notes => {
            // Ja piezīmju nav vai to skaits ir 0, attēlo paziņojumu par to
            if (!notes || notes.length === 0) {
                renderNoNotes();
                return;
            }
            // Ja piezīmes ir, izsauc funkciju to attēlošanai
            renderNotes(notes);
        })
        .catch(error => {
            // Kļūdas gadījumā izvada ziņu konsolē un attēlo kļūdas paziņojumu lietotājam
            console.error("Load Error:", error);
            renderError(error.message);
        });
}

// Funkcija, kas attēlo saņemtās piezīmes lapā
function renderNotes(notes) {
    const container = document.getElementById("notes-container");
    if (!container) return;

    container.innerHTML = ""; // Notīra iepriekšējo saturu

    // Iet cauri visām piezīmēm un izveido HTML elementus katrai piezīmei
    notes.forEach(note => {
        const noteElement = document.createElement("div");
        noteElement.className = "note-item";
        noteElement.innerHTML = `
            <h3>${escapeHtml(note.title) || 'Untitled Note'}</h3>  <!-- Piezīmes virsraksts, droša HTML izvade -->
            <p>${escapeHtml(note.content) || ''}</p>              <!-- Piezīmes saturs -->
            <small>${formatDate(note.note_date) || ''}</small>    <!-- Piezīmes datums skaistā formātā -->
            <button class="delete-note" data-id="${note.id}">     <!-- Dzēšanas poga ar piezīmes ID -->
                <span class="delete-text">Delete</span>
                <span class="spinner"></span>
            </button>
        `;
        container.appendChild(noteElement); // Pievieno piezīmes elementu konteineram
    });

    // Pievieno notikumus dzēšanas pogām
    setupDeleteHandlers();
}

// Funkcija, kas pievieno klikšķa notikumus dzēšanas pogām
function setupDeleteHandlers() {
    // Atrodam visas dzēšanas pogas
    document.querySelectorAll(".delete-note").forEach(btn => {
        btn.addEventListener("click", function() {
            const noteId = this.dataset.id; // Nolasa piezīmes ID no pogas datiem
            if (!noteId || isNaN(noteId)) {
                console.error("Invalid note ID:", noteId);
                return;
            }
            const noteElement = this.closest('.note-item'); // Atrodam piezīmes elementu, kurā ir poga
            deleteNote(noteId, noteElement); // Izsauc dzēšanas funkciju
        });
    });
}

// Funkcija, kas izdzēš piezīmi no servera un no lapas
function deleteNote(id, noteElement) {
    if (!id || !noteElement) return;

    if (!confirm("Are you sure you want to delete this note?")) return;

    // Sagatavo dzēšanas pogu statusam
    const deleteBtn = noteElement.querySelector('.delete-note');
    if (deleteBtn) {
        deleteBtn.disabled = true;
        deleteBtn.querySelector('.delete-text').textContent = 'Deleting...';
        deleteBtn.querySelector('.spinner').style.display = 'inline-block';
    }

    // 🔥 REĀLS JSON pieprasījums
    fetch("../../includes/delete_note.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ id: Number(id) }) // nodrošina, ka ID ir skaitlis
    })
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Animē dzēšanu
                noteElement.style.opacity = '0';
                setTimeout(() => {
                    noteElement.remove();
                    checkIfEmpty(); // pārbauda, vai saraksts nav tukšs
                }, 300);
            } else {
                throw new Error(data.error || "Delete failed");
            }
        })
        .catch(error => {
            console.error("Delete Error:", error);
            if (deleteBtn) {
                deleteBtn.disabled = false;
                deleteBtn.querySelector('.delete-text').textContent = 'Delete';
                deleteBtn.querySelector('.spinner').style.display = 'none';
            }
            showAlert(`Error: ${error.message}`, 'error');
        });
}


// Funkcija, kas pārbauda, vai piezīmju konteineris ir tukšs, un, ja jā, attēlo atbilstošu ziņu
function checkIfEmpty() {
    const container = document.getElementById("notes-container");
    if (!container) return;

    if (container.children.length === 0) {
        renderNoNotes();
    }
}

// Funkcija, kas attēlo paziņojumu, ja piezīmju nav
function renderNoNotes() {
    const container = document.getElementById("notes-container");
    if (container) {
        container.innerHTML = '<div class="no-notes">No notes found for today</div>';
    }
}

// Funkcija, kas attēlo kļūdas ziņojumu konteinerī
function renderError(message) {
    const container = document.getElementById("notes-container");
    if (container) {
        container.innerHTML = `<div class="error">${escapeHtml(message)}</div>`;
    }
}

// Funkcija, kas parāda īslaicīgu paziņojumu ekrānā
function showAlert(message, type = 'success') {
    const alert = document.createElement('div');
    alert.className = `alert ${type}`; // Pievieno klasi atbilstoši paziņojuma tipam (veiksmīgs vai kļūda)
    alert.textContent = message;
    document.body.appendChild(alert);

    // Pēc 3 sekundēm sāk samazināt caurspīdīgumu un pēc tam noņem paziņojumu no lapas
    setTimeout(() => {
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 300);
    }, 3000);
}

// Funkcija, kas formatē datumu cilvēkam saprotamā veidā
function formatDate(dateString) {
    if (!dateString) return '';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

// Funkcija, kas aizsargā no HTML injekcijām, pārvēršot tekstu drošā HTML formātā
function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}
