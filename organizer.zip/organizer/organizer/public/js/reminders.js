document.addEventListener("DOMContentLoaded", () => {
    // Konteiners, kurā tiks rādīti atgādinājumi
    const remindersContainer = document.getElementById("reminders-container");
    // Forma jauna atgādinājuma pievienošanai
    const reminderForm = document.getElementById("reminder-form");
    // Set, lai saglabātu jau rādītos atgādinājumus (lai popup netiktu rādīts vairākas reizes vienam atgādinājumam)
    const shownReminders = new Set();

    // Funkcija atgādinājumu ielādei no servera un to attēlošanai lapā
    function fetchReminders() {
        fetch("../../includes/get_reminders.php")
            .then(response => response.json())
            .then(data => {
                // Pārbaude, vai saņemti dati ir masīvs
                if (!Array.isArray(data)) {
                    remindersContainer.innerHTML = "<p>Failed to load reminders.</p>";
                    return;
                }

                remindersContainer.innerHTML = ""; // Notīra iepriekšējo saturu

                // Ja atgādinājumu nav
                if (data.length === 0) {
                    remindersContainer.innerHTML = "<p>No reminders yet.</p>";
                    return;
                }

                // Iziet cauri katram atgādinājumam un izveido tā HTML elementus
                data.forEach(reminder => {
                    const reminderDiv = document.createElement("div");
                    reminderDiv.className = "reminder";

                    // Ja atgādinājums ir pabeigts, pievieno klasi "done" (var izmantot stilizēšanai)
                    if (reminder.status === "done") {
                        reminderDiv.classList.add("done");
                    }

                    // Atgādinājuma pamatinformācija: uzdevuma nosaukums un laiks, noformēts lasāmā formātā
                    reminderDiv.innerHTML = `
                        <strong>Task:</strong> ${reminder.task_title}<br>
                        <strong>Reminder Time:</strong> ${formatDateTime(reminder.reminder_date)}
                        <br><br>
                    `;

                    // Poga statusa pārslēgšanai (Done <-> Pending)
                    const toggleBtn = document.createElement("button");
                    toggleBtn.className = "toggle-status";
                    toggleBtn.textContent = `Mark as ${reminder.status === "pending" ? "Done" : "Pending"}`;
                    toggleBtn.dataset.id = reminder.id;

                    reminderDiv.appendChild(toggleBtn);

                    // Poga atgādinājuma dzēšanai
                    const removeBtn = document.createElement("button");
                    removeBtn.textContent = "Remove";
                    removeBtn.className = "remove-reminder";
                    // Stilizēšana - sarkans fons, balts teksts utt.
                    removeBtn.style.backgroundColor = "#e53935";
                    removeBtn.style.color = "white";
                    removeBtn.style.border = "none";
                    removeBtn.style.marginLeft = "1rem";
                    removeBtn.style.padding = "5px 10px";
                    removeBtn.style.cursor = "pointer";
                    removeBtn.dataset.id = reminder.id;

                    // Dzēšanas pogas klikšķa apstrāde
                    removeBtn.addEventListener("click", () => {
                        if (!confirm("Are you sure you want to remove this reminder?")) return;

                        fetch("../../includes/delete_reminder.php", {
                            method: "POST",
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            body: `id=${removeBtn.dataset.id}`
                        })
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    fetchReminders(); // Pārlādē sarakstu pēc dzēšanas
                                } else {
                                    alert("Error deleting reminder.");
                                }
                            })
                            .catch(err => {
                                console.error("Delete failed:", err);
                                alert("Failed to delete reminder.");
                            });
                    });

                    reminderDiv.appendChild(removeBtn);

                    // Pievieno atgādinājuma elementu konteineram
                    remindersContainer.appendChild(reminderDiv);

                    // Pārbauda, vai atgādinājums jāparāda kā popup tieši tagad
                    const now = new Date();
                    const reminderTime = new Date(reminder.reminder_date);

                    // Pārbauda vai atgādinājuma laiks sakrīt ar pašreizējo minūti
                    const sameMinute = now.getFullYear() === reminderTime.getFullYear()
                        && now.getMonth() === reminderTime.getMonth()
                        && now.getDate() === reminderTime.getDate()
                        && now.getHours() === reminderTime.getHours()
                        && now.getMinutes() === reminderTime.getMinutes();

                    // Unikāls identifikators atgādinājumam, lai neparādītu popup atkārtoti vienam un tam pašam
                    const uniqueId = `${reminder.id}-${reminder.reminder_date}`;

                    // Ja atgādinājums ir "pending", laiks sakrīt un tas vēl nav rādīts popup, tad parāda to
                    if (reminder.status === "pending" && sameMinute && !shownReminders.has(uniqueId)) {
                        shownReminders.add(uniqueId);
                        showReminderPopup(reminder.task_title);
                    }
                });

                // Pievieno notikumus pogām, lai pārslēgtu statusu
                document.querySelectorAll(".toggle-status").forEach(button => {
                    button.addEventListener("click", () => {
                        const id = button.dataset.id;
                        fetch("../../includes/toggle_status.php", {
                            method: "POST",
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            body: `id=${id}`
                        })
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    fetchReminders(); // Atjauno sarakstu pēc statusa maiņas
                                } else {
                                    alert("Error: " + (data.error || "Failed to update status"));
                                }
                            });
                    });
                });
            })
            .catch(err => {
                console.error("Failed to load reminders:", err);
                remindersContainer.innerHTML = "<p>Error loading reminders.</p>";
            });
    }

    // Funkcija datuma/laika formatēšanai saprotamā veidā
    function formatDateTime(datetimeStr) {
        const dt = new Date(datetimeStr);
        return dt.toLocaleString(undefined, {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        });
    }

    // Funkcija atgādinājuma popup rādīšanai ekrānā
    function showReminderPopup(taskTitle) {
        const banner = document.createElement("div");
        banner.textContent = `🔔 Reminder: ${taskTitle}`;
        // Stilizē banneri — fiksēta pozīcija augšpusē, spilgtas krāsas utt.
        banner.style.position = "fixed";
        banner.style.top = "0";
        banner.style.left = "0";
        banner.style.right = "0";
        banner.style.padding = "1rem";
        banner.style.backgroundColor = "#6200ea";
        banner.style.color = "white";
        banner.style.textAlign = "center";
        banner.style.zIndex = "9999";
        banner.style.fontWeight = "bold";
        banner.style.boxShadow = "0 2px 6px rgba(0,0,0,0.2)";
        document.body.appendChild(banner);

        // Noņem banneri pēc 10 sekundēm
        setTimeout(() => {
            banner.remove();
        }, 10000);
    }

    // Apstrādā jauna atgādinājuma pievienošanas formu
    if (reminderForm) {
        reminderForm.addEventListener("submit", (e) => {
            e.preventDefault();

            // Iegūst formā ievadītos datus
            const eventId = document.getElementById("reminder-task").value;
            const reminderDatetime = document.getElementById("reminder-datetime").value;

            // Vienkārša validācija - obligāti jāizvēlas uzdevums un laiks
            if (!eventId || !reminderDatetime) {
                alert("Please select a task and date/time.");
                return;
            }

            // Nosūta datus serverim, lai pievienotu atgādinājumu
            fetch("../../includes/add_reminder.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: `event_id=${encodeURIComponent(eventId)}&reminder_datetime=${encodeURIComponent(reminderDatetime)}`
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert("Reminder added successfully!");
                        reminderForm.reset(); // Atiestata formu
                        fetchReminders();    // Atjauno sarakstu ar jaunajiem atgādinājumiem
                    } else {
                        //alert("Failed to add reminder: " + (data.error || "Unknown error"));
                    }
                })
                .catch(err => {
                    console.error("Error adding reminder:", err);
                    alert("Network error adding reminder.");
                });
        });
    }

    fetchReminders();           // Ielādē atgādinājumus sākumā
    setInterval(fetchReminders, 60000); // Atjauno katru minūti
});
