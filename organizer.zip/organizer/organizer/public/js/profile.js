document.addEventListener("DOMContentLoaded", () => {
    // Avatar augšupielādes funkcionalitāte
    const avatarUpload = document.getElementById('avatar-upload'); // fails augšupielādei
    const changeAvatarBtn = document.getElementById('change-avatar'); // poga, kas atver faila izvēli
    const profileAvatar = document.getElementById('profile-avatar'); // attēla elements, kur rāda avataru

    // Kad spiež pogu "Mainīt avataru", atver faila izvēli
    changeAvatarBtn.addEventListener('click', () => {
        avatarUpload.click();
    });

    // Kad fails izvēlēts, ielādē to un attēlo kā avataru
    avatarUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                profileAvatar.src = event.target.result; // attēlo jauno avataru
                // Šeit parasti sūtītu attēlu uz serveri augšupielādei
            };
            reader.readAsDataURL(file);
        }
    });

    // Profila formas iesniegšana
    const profileForm = document.getElementById('profile-form');
    profileForm.addEventListener('submit', (e) => {
        e.preventDefault(); // aptur formu no lapas pārlādes

        // Parbauda, vai paroles sakrīt, ja ir ievadītas
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm-password').value;

        if (password && password !== confirmPassword) {
            alert("Paroles nesakrīt!");
            return; // pārtrauc, ja paroles nesakrīt
        }

        // Šeit parasti sūta datus uz serveri profila atjaunošanai
        alert("Profils veiksmīgi atjaunots!");
    });

    // Izrakstīšanās poga
    document.getElementById('logout-btn').addEventListener('click', () => {
        if (confirm("Vai tiešām vēlaties izrakstīties?")) {
            // Šeit parasti dzēstu sesijas datus un novirzītu uz sākumlapu
            window.location.href = "../html/main.html";
        }
    });

    // Datu eksportēšanas poga
    document.getElementById('export-data').addEventListener('click', () => {
        alert("Jūsu dati tiek sagatavoti lejupielādei. Jūs saņemsiet e-pastu, kad tas būs gatavs.");
        // Šeit parasti sāk servera puses datu eksportu un nosūta paziņojumu
    });

    // Konta dzēšanas poga
    document.getElementById('delete-account').addEventListener('click', () => {
        if (confirm("Vai tiešām esat pārliecināts? Šī darbība neatgriezeniski dzēsīs jūsu kontu un visus datus!")) {
            if (prompt("Ierakstiet 'DELETE', lai apstiprinātu:") === "DELETE") {
                alert("Konta dzēšanas pieprasījums saņemts. Jūs saņemsiet apstiprinājuma e-pastu.");
                // Šeit parasti sūta dzēšanas pieprasījumu serverim
            }
        }
    });
});
