document.addEventListener("DOMContentLoaded", () => {
    // DOM Elements
    const calendar = document.getElementById("calendar");
    const eventForm = document.getElementById("event-form");
    const reminderForm = document.getElementById("reminder-form");
    const noteForm = document.getElementById("note-form");
    const prevMonthBtn = document.getElementById("prev-month");
    const nextMonthBtn = document.getElementById("next-month");
    const currentMonthDisplay = document.getElementById("current-month");
    const allTasksContainer = document.getElementById("all-tasks-container");
    const notesContainer = document.getElementById("notes-container");

    // State variables
    let currentDate = new Date();
    let events = [];
    let notes = [];
    let noteDates = [];

    // Base URL configuration
    const baseUrl = window.location.origin + '/organizer/organizer/'; // Adjust to your project root

    // Initialize the calendar
    function initCalendar() {
        updateMonthDisplay();
        prevMonthBtn.addEventListener("click", () => changeMonth(-1));
        nextMonthBtn.addEventListener("click", () => changeMonth(1));

        // Setup form event listeners
        if (eventForm) eventForm.addEventListener("submit", handleEventSubmit);
        if (reminderForm) reminderForm.addEventListener("submit", handleReminderSubmit);
        if (noteForm) noteForm.addEventListener("submit", handleNoteSubmit);

        loadCalendarData();
    }

    // Handle event form submission
    function handleEventSubmit(e) {
        e.preventDefault();
        const formData = new FormData(eventForm);

        fetch(`${baseUrl}/includes/add_event.php`, {
            method: "POST",
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    eventForm.reset();
                    loadCalendarData();
                } else {
                    throw new Error(data.error || "Failed to add event");
                }
            })
            .catch(error => {
                console.error("Event creation error:", error);
                showAlert("Error: " + error.message, 'error');
            });
    }

    // Handle reminder form submission
    function handleReminderSubmit(e) {
        e.preventDefault();
        const formData = new FormData(reminderForm);

        fetch(`${baseUrl}/includes/add_reminder.php`, {
            method: "POST",
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    reminderForm.reset();
                    showAlert("Reminder added successfully!", 'success');
                } else {
                    throw new Error(data.error || "Failed to add reminder");
                }
            })
            .catch(error => {
                console.error("Reminder creation error:", error);
                showAlert("Error: " + error.message, 'error');
            });
    }

    // Handle note form submission
    function handleNoteSubmit(e) {
        e.preventDefault();
        const formData = new FormData(noteForm);

        fetch(`${baseUrl}/includes/add_note.php`, {
            method: "POST",
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    noteForm.reset();
                    loadCalendarData(); // Refresh the entire calendar
                } else {
                    throw new Error(data.error || "Failed to add note");
                }
            })
            .catch(error => {
                console.error("Note creation error:", error);
                showAlert("Error: " + error.message, 'error');
            });
    }

    // Load all calendar data
    function loadCalendarData() {
        Promise.all([
            fetchEvents(),
            fetchNotes(),
            fetchNoteDates()
        ]).then(() => {
            generateCalendar(currentDate.getFullYear(), currentDate.getMonth());
            displayAllTasks();
            displayAllNotes();
        });
    }

    // Update month display
    function updateMonthDisplay() {
        const options = { year: 'numeric', month: 'long' };
        currentMonthDisplay.textContent = currentDate.toLocaleDateString('en-US', options);
    }

    // Fetch events
    function fetchEvents() {
        return fetch(`${baseUrl}/includes/get_events.php`)
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                events = data.map(event => ({
                    ...event,
                    event_date: formatDateForComparison(event.Event_date || event.event_date)
                }));
                return events;
            })
            .catch(error => {
                console.error("Error loading events:", error);
                events = [];
                return [];
            });
    }

    // Fetch notes
    function fetchNotes() {
        return fetch(`${baseUrl}/../includes/get_notes.php`)
            .then(response => {
                if (!response.ok) throw new Error("Failed to fetch notes");
                return response.json();
            })
            .then(data => {
                notes = Array.isArray(data) ? data : [];
                return notes;
            })
            .catch(error => {
                console.error("Error loading notes:", error);
                notes = [];
                return [];
            });
    }

    // Fetch note dates - UPDATED to use get_notes.php with date_only parameter
    function fetchNoteDates() {
        return fetch(`${baseUrl}/includes/get_notes.php?date_only=1`)
            .then(response => {
                if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                return response.json();
            })
            .then(data => {
                noteDates = Array.isArray(data) ? data : [];
                return noteDates;
            })
            .catch(error => {
                console.error("Error loading note dates:", error);
                noteDates = [];
                return [];
            });
    }

    // Display all notes
    function displayAllNotes() {
        if (!notesContainer) return;
        notesContainer.innerHTML = "";

        if (notes.length === 0) {
            notesContainer.innerHTML = "<p>No notes available</p>";
            return;
        }

        notes.forEach(note => {
            const noteElement = document.createElement("div");
            noteElement.className = "note-item";
            noteElement.innerHTML = `
                <h3>${note.title || 'Untitled Note'}</h3>
                <p>${note.content || ''}</p>
                <small>${formatDate(note.note_date)}</small>
                <button class="delete-note" data-id="${note.id}">
                    <span class="delete-text">Delete</span>
                    <span class="spinner"></span>
                </button>
            `;
            notesContainer.appendChild(noteElement);
        });

        // Add event listeners to delete buttons
        document.querySelectorAll(".delete-note").forEach(btn => {
            btn.addEventListener("click", function() {
                deleteNote(this.dataset.id);
            });
        });
    }

    // Delete note - UPDATED VERSION
    function deleteNote(noteId) {
        if (!noteId || isNaN(noteId)) {
            console.error("Invalid note ID format:", noteId);
            showAlert("Invalid note ID format", 'error');
            return;
        }

        if (!confirm("Are you sure you want to delete this note?")) return;

        const deleteButtons = document.querySelectorAll(`.delete-note[data-id="${noteId}"]`);
        deleteButtons.forEach(btn => {
            btn.disabled = true;
            const textSpan = btn.querySelector('.delete-text');
            if (textSpan) textSpan.textContent = 'Deleting...';
        });

        fetch(`${baseUrl}/includes/delete_note.php`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest"
            },
            body: JSON.stringify({ id: noteId })
        })
            .then(response => {
                if (response.status === 400) throw new Error("Invalid note ID format");
                if (response.status === 401) throw new Error("Please login again");
                if (response.status === 404) throw new Error("Note not found");
                if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    showAlert("Note deleted successfully", 'success');
                    loadCalendarData(); // Refresh the calendar
                } else {
                    throw new Error(data.error || "Delete failed");
                }
            })
            .catch(error => {
                console.error("Delete Error:", error);
                showAlert(`Delete failed: ${error.message}`, 'error');
            })
            .finally(() => {
                deleteButtons.forEach(btn => {
                    btn.disabled = false;
                    const textSpan = btn.querySelector('.delete-text');
                    if (textSpan) textSpan.textContent = 'Delete';
                });
            });
    }

    // Generate calendar grid
    function generateCalendar(year, month) {
        calendar.innerHTML = "";

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        // Empty cells for days before the first of the month
        for (let i = 0; i < firstDay; i++) {
            calendar.appendChild(createEmptyCell());
        }

        // Create cells for each day
        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
            calendar.appendChild(createCalendarCell(day, dateStr));
        }
    }

    // Helper functions
    function createEmptyCell() {
        const cell = document.createElement("div");
        cell.classList.add("calendar-cell", "empty-cell");
        return cell;
    }

    function createCalendarCell(day, dateStr) {
        const cell = document.createElement("div");
        cell.textContent = day;
        cell.dataset.date = dateStr;
        cell.classList.add("calendar-cell");

        // Check for events
        const eventsForDate = events.filter(event => event.event_date === dateStr);
        if (eventsForDate.length > 0) {
            cell.classList.add("has-events");
            const eventIndicators = createEventIndicators(eventsForDate);
            cell.appendChild(eventIndicators);
        }

        // Check for notes - updated to properly display note indicators
        if (noteDates.includes(dateStr)) {
            const noteIndicator = document.createElement("div");
            noteIndicator.className = "note-indicator";
            noteIndicator.title = "Has notes";
            cell.appendChild(noteIndicator);
        }

        cell.addEventListener("click", () => showDateDetails(dateStr, eventsForDate));
        return cell;
    }

    // Updated showDateDetails to include notes
    function showDateDetails(date, events) {
        // Fetch notes for this date
        fetch(`${baseUrl}/includes/get_notes.php?date=${date}`)
            .then(response => response.json())
            .then(notes => {
                let message = `Date: ${formatDate(date)}\n\n`;

                // Add events section
                message += "Events:\n";
                message += events.length > 0
                    ? events.map(e => `• ${e.title}`).join('\n')
                    : "No events scheduled";

                // Add notes section
                message += "\n\nNotes:\n";
                message += notes.length > 0
                    ? notes.map(n => `• ${n.title}: ${n.content.substring(0, 30)}...`).join('\n')
                    : "No notes for this date";

                alert(message);
            })
            .catch(error => {
                console.error("Error fetching notes:", error);
                alert(`Date: ${formatDate(date)}\n\nEvents:\n${
                    events.length > 0
                        ? events.map(e => `• ${e.title}`).join('\n')
                        : "No events scheduled"
                }`);
            });
    }

    function displayAllTasks() {
        allTasksContainer.innerHTML = "";

        if (events.length === 0) {
            allTasksContainer.innerHTML = "<p class='no-tasks'>No events found</p>";
            return;
        }

        const taskList = document.createElement("ul");
        taskList.className = "task-items";

        // Sort events by date (newest first)
        const sortedEvents = [...events].sort((a, b) =>
            new Date(b.event_date) - new Date(a.event_date));

        sortedEvents.forEach(event => {
            const taskItem = document.createElement("li");
            taskItem.className = "task-item";
            taskItem.innerHTML = `
                <span class="task-date">${formatDate(event.event_date)}</span>
                <span class="task-title">${event.title}</span>
                <button class="delete-task" data-id="${event.id}">🗑</button>
            `;
            taskList.appendChild(taskItem);
        });

        allTasksContainer.appendChild(taskList);

        // Add event listeners to delete buttons
        document.querySelectorAll(".delete-task").forEach(btn => {
            btn.addEventListener("click", (e) => {
                e.stopPropagation();
                deleteTask(e.target.dataset.id);
            });
        });
    }

    function deleteTask(taskId) {
        if (!confirm("Are you sure you want to delete this event?")) return;

        fetch(`${baseUrl}/includes/delete_event.php`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: taskId })
        })
            .then(response => {
                if (!response.ok) throw new Error("Network error");
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    loadCalendarData();
                } else {
                    throw new Error(data.error || "Delete failed");
                }
            })
            .catch(error => {
                console.error("Delete error:", error);
                showAlert("Error: " + error.message, 'error');
            });
    }

    function formatDate(dateString) {
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('en-US', options);
    }

    function formatDateForComparison(dateString) {
        try {
            const date = new Date(dateString);
            if (isNaN(date.getTime())) throw new Error("Invalid date");
            return date.toISOString().split('T')[0];
        } catch (e) {
            console.error("Date formatting error:", e);
            return "";
        }
    }

    function createEventIndicators(events) {
        const container = document.createElement("div");
        container.className = "event-indicators";
        events.forEach(event => {
            const indicator = document.createElement("div");
            indicator.className = "event-indicator";
            indicator.title = event.title;
            container.appendChild(indicator);
        });
        return container;
    }

    function changeMonth(offset) {
        currentDate.setMonth(currentDate.getMonth() + offset);
        updateMonthDisplay();
        loadCalendarData();
    }

    // Alert notification function
    function showAlert(message, type = 'success') {
        const alert = document.createElement('div');
        alert.className = `alert ${type}`;
        alert.textContent = message;
        document.body.appendChild(alert);

        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        }, 3000);
    }

    // Initialize the calendar
    initCalendar();
});