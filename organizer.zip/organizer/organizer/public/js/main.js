document.addEventListener("DOMContentLoaded", () => {
    const taskCount = document.getElementById("task-count");
    const noteCount = document.getElementById("note-count");
    const eventCount = document.getElementById("event-count");

    // Piemēra dati
    const tasks = ["Task 1", "Task 2"];
    const notes = ["Note 1"];
    const events = ["Event 1", "Event 2"];

    // Atjauno skaitu dinamiski
    taskCount.textContent = tasks.length;
    noteCount.textContent = notes.length;
    eventCount.textContent = events.length;

    // Pogu funkcionalitāte
    document.getElementById("add-task-btn").addEventListener("click", () => {
        alert("Add Task clicked!");
    });

    document.getElementById("add-note-btn").addEventListener("click", () => {
        alert("Add Note clicked!");
    });

    document.getElementById("view-calendar-btn").addEventListener("click", () => {
        alert("View Calendar clicked!");
    });
});
