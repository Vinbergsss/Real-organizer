<?php
session_start(); // Sāk sesiju, lai piekļūtu lietotāja datiem
require '../../includes/db.php'; // Iekļauj datubāzes savienojuma failu

// Pārbauda, vai lietotājs ir pieslēdzies
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html"); // Ja nav, pāradresē uz pieslēgšanās lapu
    exit;
}

$user_id = $_SESSION['user_id']; // Saglabā lietotāja ID

// Sagatavo vaicājumu, lai iegūtu lietotāja piezīmes
$stmt = $conn->prepare("SELECT id, title, content, note_date FROM notes WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Notes</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
<h1>Your Notes</h1>
<a href="calendar.html">← Back to Calendar</a>

<?php if ($result->num_rows > 0): // Ja ir piezīmes ?>
    <ul>
        <?php while ($note = $result->fetch_assoc()): // Iziet cauri katrai piezīmei ?>
            <li style="margin-bottom: 1rem;">
                <strong><?= htmlspecialchars($note['title']) ?></strong> (<?= $note['note_date'] ?>)<br>
                <?= nl2br(htmlspecialchars($note['content'])) ?>
                <!-- Forma piezīmes dzēšanai -->
                <form method="POST" action="../../includes/delete_note.php" style="margin-top: 0.5rem;">
                    <input type="hidden" name="note_id" value="<?= $note['id'] ?>">
                    <button type="submit">Delete</button>
                </form>
            </li>
        <?php endwhile; ?>
    </ul>
<?php else: // Ja piezīmju nav ?>
    <p>No notes yet. Add one from the calendar!</p>
<?php endif; ?>

</body>
</html>
