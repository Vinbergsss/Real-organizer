<?php
// Sāk sesiju, lai varētu piekļūt sesijas datiem
session_start();
// Iekļauj datubāzes savienojuma failu
require_once 'db.php';

// Skaidri definē $conn kā globālu mainīgo
global $conn;

// Iestata atbildes galveni, ka tiks sūtīts JSON formāts
header("Content-Type: application/json");

// Pārbauda, vai datubāzes savienojums ir definēts un ir mysqli objekts
if (!isset($conn) || !($conn instanceof mysqli)) {
    // Ja nav, atgriež 500 kļūdas kodu un JSON paziņojumu par savienojuma kļūdu
    http_response_code(500);
    die(json_encode(['success' => false, 'error' => 'Database connection failed']));
}

// Nolasa ienākošos datus no JSON POST ķermeņa un dekodē tos uz asociatīvu masīvu
$input = json_decode(file_get_contents("php://input"), true);

// Pārbauda, vai ir definēts 'id' un vai tas ir skaitlis
if (!isset($input['id']) || !is_numeric($input['id'])) {
    // Ja nav vai nav derīgs, atgriež 400 kļūdas kodu un kļūdas paziņojumu
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Invalid event ID']));
}

// Konvertē id uz veselu skaitli, lai droši izmantotu datubāzes vaicājumā
$id = (int)$input['id'];

try {
    // Sagatavo SQL vaicājumu notikuma dzēšanai no tabulas "events" pēc id
    // Nav lietotāja pārbaudes, jo tabulā nav user_id kolonnas
    $stmt = $conn->prepare("DELETE FROM events WHERE id = ?");
    if (!$stmt) {
        // Ja sagatavošana neizdodas, met izņēmumu ar kļūdas ziņojumu
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Piesaista id kā veselu skaitli vaicājumam
    $stmt->bind_param("i", $id);

    // Izpilda dzēšanas vaicājumu
    if ($stmt->execute()) {
        // Atgriež JSON ar veiksmīgu izpildi un informāciju, vai tika dzēsts kāds ieraksts
        echo json_encode([
            'success' => true,
            'deleted' => $stmt->affected_rows > 0
        ]);
    } else {
        // Ja izpilde neizdodas, met izņēmumu ar kļūdas ziņojumu
        throw new Exception($stmt->error);
    }
} catch (Exception $e) {
    // Kļūdas gadījumā atgriež 500 servera kļūdas kodu un kļūdas tekstu JSON formātā
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} finally {
    // Noslēdz sagatavoto vaicājumu un datubāzes savienojumu
    if (isset($stmt)) $stmt->close();
    $conn->close();
}
?>
