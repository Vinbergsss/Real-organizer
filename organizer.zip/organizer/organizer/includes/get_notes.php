<?php
session_start();  // Sāk sesiju, lai varētu strādāt ar sesijas mainīgajiem
require_once 'db.php';  // Iekļauj datubāzes savienojuma failu

header("Content-Type: application/json");  // Nosaka atbildes tipu kā JSON

// Pārbauda, vai datubāzes savienojums ir izveidots un nav kļūdu
if (!isset($conn) || $conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Pārbauda, vai lietotājs ir ielogojies (sesijā ir 'user_id')
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'User not logged in']);
    exit;
}

// Aizsargā sesijas lietotāja ID pret SQL injekciju
$userId = $conn->real_escape_string($_SESSION['user_id']);

try {
    // Ja GET pieprasījumā ir norādīts 'date_only', tad atlasa unikālos datumu ierakstus no piezīmēm
    if (isset($_GET['date_only'])) {
        $query = "SELECT DISTINCT id, title, content, note_date FROM notes WHERE user_id = $userId";
        $result = $conn->query($query);

        $dates = [];
        while ($row = $result->fetch_assoc()) {
            $dates[] = $row['note_date'];  // Ievieto katru unikālo datumu masīvā
        }

        echo json_encode($dates);  // Atgriež JSON masīvu ar datumiem
        exit;
    }

    // Ja GET pieprasījumā ir norādīts konkrēts 'date', atlasām piezīmes konkrētajā datumā
    if (isset($_GET['date'])) {
        // Aizsargā datuma vērtību pret SQL injekciju
        $date = $conn->real_escape_string($_GET['date']);
        $query = "SELECT id, title, content, note_date FROM notes WHERE user_id = $userId AND note_date = '$date'";
    } else {
        // Ja datums nav norādīts, tad atlasa visus unikālos piezīmju datumus
        $query = "SELECT DISTINCT id, title, content, note_date FROM notes WHERE user_id = $userId";
    }

    $result = $conn->query($query);

    if (!$result) {
        throw new Exception($conn->error);  // Izmet izņēmumu, ja vaicājums neizdodas
    }

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;  // Saglabā rezultātus masīvā
    }

    echo json_encode($data);  // Atgriež datus JSON formātā
    exit;

} catch (Exception $e) {
    http_response_code(500);  // Atbild ar 500 kļūdas kodu servera kļūdas gadījumā
    echo json_encode(['error' => $e->getMessage()]);  // Atgriež kļūdas ziņojumu JSON formātā
    exit;
}
?>