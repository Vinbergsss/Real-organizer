<?php
$conn = new mysqli("database-1.cd0m46mqkm83.eu-north-1.rds.amazonaws.com", "admin", "HyperX3146!", "organizer_db");

// Pārbauda savienojumu
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}


$conn->set_charset("utf8mb4");
?>
