<?php
$conn = new mysqli("database-1.cd0m46mqkm83.eu-north-1.rds.amazonaws.com", "admin", "HyperX3146!", "organizer_db");

// Pārbauda savienojumu
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
define('TIMEZONE', 'Europe/Riga');
date_default_timezone_set(TIMEZONE);
$conn->query("SET time_zone='".TIMEZONE."';");

$conn->set_charset("utf8mb4");
?>