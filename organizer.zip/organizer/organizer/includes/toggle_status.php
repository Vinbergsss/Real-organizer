<?php
session_start();
require_once 'db.php';

header("Content-Type: application/json");

if (!isset($_SESSION['user_id']) || !isset($_POST['id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$reminder_id = $_POST['id'];

// Iegūst pašreizējo statusu
$stmt = $conn->prepare("SELECT status FROM reminders WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $reminder_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo json_encode(['success' => false, 'error' => 'Reminder not found']);
    exit;
}

$current = $result->fetch_assoc()['status'];
$new_status = ($current === 'pending') ? 'done' : 'pending';

// Update
$update = $conn->prepare("UPDATE reminders SET status = ? WHERE id = ? AND user_id = ?");
$update->bind_param("sii", $new_status, $reminder_id, $user_id);

if ($update->execute()) {
    echo json_encode(['success' => true, 'new_status' => $new_status]);
} else {
    echo json_encode(['success' => false, 'error' => 'Update failed']);
}

$conn->close();
?>
