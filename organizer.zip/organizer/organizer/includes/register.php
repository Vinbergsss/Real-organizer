<?php
session_start();
// Sāk sesiju, lai varētu izmantot sesijas mainīgos

include '../includes/db.php';
// Iekļauj datubāzes savienojuma failu

if (!isset($conn) || !$conn) {
    // Pārbauda, vai datubāzes savienojums ir izveidots
    header("Location: ../public/html/register.html?error=" . urlencode("Database connection failed!"));
    // Ja nav savienojuma, pāradresē uz reģistrācijas lapu ar kļūdas ziņojumu
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ja pieprasījums ir POST metode (forma iesniegta)

    $username = trim($_POST['username']);
    // Saņem un apstrādā lietotājvārdu (noņem liekās atstarpes)
    $email = trim($_POST['email']);
    // Saņem un apstrādā e-pastu
    $password = $_POST['password'];
    // Saņem paroli
    $confirm_password = $_POST['confirm_password'];
    // Saņem paroles apstiprinājumu

    // Validē paroles stiprumu ar regulāro izteiksmi
    $password_pattern = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/";
    if (!preg_match($password_pattern, $password)) {
        // Ja parole neatbilst prasībām (mazie un lielie burti, cipars, speciālais simbols, vismaz 8 rakstzīmes)
        $error = "Password must be at least 8 characters long, contain uppercase and lowercase letters, a number, and a special character.";
        // Pāradresē atpakaļ ar kļūdas ziņojumu un iepriekš aizpildītiem laukiem
        header("Location: ../public/html/register.html?error=" . urlencode($error) .
            "&username=" . urlencode($username) .
            "&email=" . urlencode($email));
        exit();
    }

    // Pārbauda, vai parole un apstiprinājums sakrīt
    if ($password !== $confirm_password) {
        $error = "Passwords don't match!";
        // Pāradresē atpakaļ ar kļūdu
        header("Location: ../public/html/register.html?error=" . urlencode($error) .
            "&username=" . urlencode($username) .
            "&email=" . urlencode($email));
        exit();
    }

    // Pārbauda, vai datubāzē jau ir reģistrēts šāds e-pasts
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Ja e-pasts jau eksistē
        $error = "Email already registered!";
        header("Location: ../public/html/register.html?error=" . urlencode($error) .
            "&username=" . urlencode($username) .
            "&email=" . urlencode($email));
        $stmt->close();
        exit();
    }
    $stmt->close();

    // Pārbauda, vai lietotājvārds jau ir aizņemts
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Ja lietotājvārds jau aizņemts
        $error = "Username already taken!";
        header("Location: ../public/html/register.html?error=" . urlencode($error) .
            "&username=" . urlencode($username) .
            "&email=" . urlencode($email));
        $stmt->close();
        exit();
    }
    $stmt->close();

    // Šifrē paroli, lai to droši saglabātu datubāzē
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Sagatavo SQL vaicājumu lietotāja datiem ielikt datubāzē
    $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $hashed_password);

    if ($stmt->execute()) {
        // Ja ievietošana izdevās
        $success = "Registration successful! Please login.";
        header("Location: ../public/html/index.html?registered=1");
        exit;
    } else {
        // Ja radās kļūda
        $error = "Error occurred. Please try again.";
        header("Location: ../public/html/register.html?error=" . urlencode($error) .
            "&username=" . urlencode($username) .
            "&email=" . urlencode($email));
    }

    $stmt->close();
}

$conn->close();
// Aizver datubāzes savienojumu
?>
