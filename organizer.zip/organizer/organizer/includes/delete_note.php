<?php
// Sāk sesiju, lai piekļūtu lietotāja sesijas datiem
session_start();
// Iekļauj datubāzes savienojuma failu
require_once 'db.php';

// Nosaka, ka atbilde būs JSON formātā
header("Content-Type: application/json");

// Pārbauda, vai ir izveidots datubāzes savienojums un nav kļūdu
if (!isset($conn) || $conn->connect_error) {
    // Ja savienojums nav derīgs, atgriež HTTP 500 kļūdu un paziņojumu JSON formātā
    http_response_code(500);
    die(json_encode(['success' => false, 'error' => 'Database connection failed']));
}

// Pārbauda, vai lietotājs ir autorizējies (sesijā ir user_id)
if (!isset($_SESSION['user_id'])) {
    // Ja nav autorizēts, atgriež 401 Unauthorized kļūdu
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Unauthorized access']));
}

// Nolasa ienākošo JSON datu ķermeni un dekodē to uz masīvu
$input = json_decode(file_get_contents('php://input'), true);
// Pārbauda, vai JSON dekodēšana bija veiksmīga
if (json_last_error() !== JSON_ERROR_NONE) {
    // Ja ne, atgriež 400 Bad Request kļūdu un atbilstošu paziņojumu
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Invalid JSON input']));
}

// Pārbauda, vai ir definēts 'id' un vai tas ir skaitlis
if (!isset($input['id']) || !is_numeric($input['id'])) {
    // Ja nē, atgriež 400 kļūdu un ziņu par nederīgu ID formātu
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Invalid note ID format']));
}

// Saglabā ID kā veselu skaitli
$noteId = (int)$input['id'];
// No sesijas ņem lietotāja ID (drošības nolūkos arī pārvērš par veselu skaitli)
$userId = (int)$_SESSION['user_id'];

try {
    // Pārbauda, vai piezīme ar šo ID pieder konkrētajam lietotājam
    $checkStmt = $conn->prepare("SELECT id FROM notes WHERE id = ? AND user_id = ?");
    $checkStmt->bind_param("ii", $noteId, $userId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    // Ja piezīme netika atrasta vai nepieder lietotājam, atgriež 404 kļūdu
    if ($checkResult->num_rows === 0) {
        http_response_code(404);
        die(json_encode(['success' => false, 'error' => 'Note not found or access denied']));
    }
    //$checkStmt->close();

    // Ja piezīme ir atrasta un lietotājam piederoša, veic dzēšanu
    $deleteStmt = $conn->prepare("DELETE FROM notes WHERE id = ? AND user_id = ?");
    $deleteStmt->bind_param("ii", $noteId, $userId);

    if ($deleteStmt->execute()) {
        $response = [
            'success' => true,
            'deleted' => $deleteStmt->affected_rows > 0
        ];

        if ($response['deleted']) {
            // Ieraksta dzēšanas notikumu servera žurnālā (error_log)
            error_log("Note $noteId successfully deleted by user $userId");

            // Papildus ieraksts audita žurnālā ar detaļām
            $auditStmt = $conn->prepare("INSERT INTO audit_log (user_id, action, details) VALUES (?, 'delete_note', ?)");
            $details = json_encode(['note_id' => $noteId]);
            $auditStmt->bind_param("is", $userId, $details);
            $auditStmt->execute();
            //  $auditStmt->close();
        } else {
            // Teorētiski neizpildās, jo iepriekš jau pārbaudīts, bet aizsardzībai
            $response['error'] = 'Note could not be deleted';
        }

        // Atgriež rezultātu JSON formātā
        echo json_encode($response);
    } else {
        // Ja dzēšana neizdodas, met izņēmumu ar kļūdas ziņojumu
        throw new Exception("Database error: " . $deleteStmt->error);
    }
} catch (Exception $e) {
    // Kļūdas gadījumā atgriež 500 kļūdas kodu un detalizētu kļūdas ziņojumu JSON formātā
    // Pievienots 'debug' lauks izstrādei, to vajadzētu noņemt ražošanā
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'debug' => ['note_id' => $noteId, 'user_id' => $userId]
    ]);
} finally {
    // Noslēdz visus vaicājumus, ja tie eksistē, un datubāzes savienojumu
    if (isset($checkStmt)) {
        $checkStmt->close();
    }
    if (isset($deleteStmt)){
        $deleteStmt->close();
    }
    if (isset($auditStmt)) {
        $auditStmt->close();
    }
    $conn->close();
}
?>