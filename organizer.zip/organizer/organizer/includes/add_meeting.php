<?php
// Globālais datubāzes savienojuma mainīgais
global $conn;

// Iespējo visu kļūdu ziņošanu
error_reporting(E_ALL);
// Uzstāda, lai kļūdas tiktu rādītas ekrānā
ini_set('display_errors', 1);

// Iekļauj datubāzes savienojuma failu
include 'db.php';

// Sāk sesiju
session_start();

// Pārbauda, vai lietotājs ir pieslēdzies (vai sesijā ir lietotāja ID)
if (!isset($_SESSION['user_id'])) {
    // Ja nav pieslēdzies, novirza uz pieteikšanās lapu un pārtrauc izpildi
    header("Location: ../public/html/loginindex.html");
    exit;
}

// Pārbauda, vai forma tika iesniegta ar POST metodi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Iegūst lietotāja ID no sesijas
    $user_id = $_SESSION['user_id'];
    // Iegūst nosaukumu no POST datiem
    $title = $_POST['title'];
    // Iegūst tikšanās datumu no POST datiem
    $meeting_date = $_POST['meeting_date'];
    // Iegūst atgādinājuma laiku vai iestata NULL, ja tas nav aizpildīts
    $reminder_time = !empty($_POST['reminder_time']) ? $_POST['reminder_time'] : NULL;

    // Pārbauda, vai obligātie lauki nav tukši (nosaukums un datums)
    if (!empty($title) && !empty($meeting_date)) {
        // Sagatavo SQL vaicājumu datu ievietošanai tabulā "meetings"
        $stmt = $conn->prepare("INSERT INTO meetings (user_id, title, meeting_date, reminder_time) VALUES (?, ?, ?, ?)");
        // Piesaista parametrus vaicājumam: int, string, string, string (vai NULL)
        $stmt->bind_param("isss", $user_id, $title, $meeting_date, $reminder_time);

        // Izpilda vaicājumu
        if ($stmt->execute()) {
            // Ja ievietošana veiksmīga, novirza uz grafika lapu ar veiksmes ziņojumu
            header("Location: ../public/html/schedule.html?success=1");
            exit;
        } else {
            // Ja kļūda vaicājuma izpildē, izvada kļūdas tekstu
            echo "Error: " . $stmt->error;
        }

        // Aizver sagatavoto vaicājumu
        $stmt->close();
    } else {
        // Ja kāds no obligātajiem laukiem nav aizpildīts, izvada paziņojumu
        echo "All fields are required.";
    }
}

// Aizver datubāzes savienojumu
$conn->close();
?>
