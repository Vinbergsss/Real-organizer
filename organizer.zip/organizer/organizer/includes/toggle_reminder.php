<?php
// Iekļauj datubāzes savienojuma failu
global $conn;
include 'db.php';

// Nolasa ienākošo JSON datus un dekodē tos kā asociatīvu masīvu
$data = json_decode(file_get_contents("php://input"), true);

// Pārbauda, vai saņemts derīgs 'id' lauks
if (!isset($data['id'])) {
    // Ja 'id' nav, atbild ar JSON kļūdu un pārtrauc izpildi
    echo json_encode(["success" => false, "error" => "Invalid data"]);
    exit;
}

$id = $data['id'];
// Saglabā saņemto uzdevuma (atgādinājuma) ID mainīgajā

// Sagatavo SQL vaicājumu, kas pārslēdz statusu:
// Ja statuss ir 'pending' (gaida), tad pārvērš to par 'completed' (izpildīts), un otrādi
$stmt = $conn->prepare("UPDATE reminders SET status = CASE WHEN status = 'pending' THEN 'completed' ELSE 'pending' END WHERE id = ?");
$stmt->bind_param("i", $id);

// Izpilda vaicājumu un pārbauda rezultātu
if ($stmt->execute()) {
    // Ja izdevās, atbild ar JSON, kas norāda uz veiksmīgu darbību
    echo json_encode(["success" => true]);
} else {
    // Ja radās kļūda, atbild ar JSON, kurā ir kļūdas ziņojums
    echo json_encode(["success" => false, "error" => $stmt->error]);
}

// Aizver sagatavoto vaicājumu un datubāzes savienojumu
$stmt->close();
$conn->close();
?>
