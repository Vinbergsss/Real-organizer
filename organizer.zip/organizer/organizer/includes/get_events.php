<?php
// Padara datubāzes savienojumu globāli pieejamu
global $conn;
// Iekļauj datubāzes savienojuma failu
include 'db.php';

// Sagatavo SQL vaicājumu, lai iegūtu notikumus no tabulas 'events'
// Atlasām id, Event_date kā event_date, un title, kārtojam pēc datuma augošā secībā
$stmt = $conn->prepare("SELECT id, Event_date AS event_date, title FROM events ORDER BY Event_date ASC");

// Izpilda vaicājumu
$stmt->execute();

// Saņem rezultātu kopu
$result = $stmt->get_result();

// Inicializē tukšu masīvu notikumiem
$events = [];

// Ciklā pa vienam ierakstam ievieto tos masīvā
while ($row = $result->fetch_assoc()) {
    $events[] = $row;
}

// Aizver sagatavoto vaicājumu
$stmt->close();
// Aizver datubāzes savienojumu
$conn->close();

// Nosaka atbildes galveni kā JSON formātu
header("Content-Type: application/json");

// Izvada notikumu masīvu JSON formātā
echo json_encode($events);
?>
