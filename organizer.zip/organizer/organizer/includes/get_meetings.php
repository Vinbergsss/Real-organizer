<?php
// Padara datubāzes savienojumu globāli pieejamu
global $conn;
// Iekļauj datubāzes savienojuma failu
include 'db.php';

// Sāk sesiju, lai varētu piekļūt sesijas mainīgajiem
session_start();

// Pārbauda, vai lietotājs ir ielogojies (vai sesijā ir 'user_id')
if (!isset($_SESSION['user_id'])) {
    // Ja nav ielogojies, atgriež tukšu JSON masīvu un pārtrauc izpildi
    echo json_encode([]);
    exit;
}

// Izņem no sesijas lietotāja ID
$user_id = $_SESSION['user_id'];

// Sagatavo SQL vaicājumu, lai iegūtu tikšanās datus konkrētam lietotājam
// Atlasām nosaukumu, tikšanās datumu un atgādinājuma laiku, kārtojam pēc tikšanās datuma augošā secībā
$stmt = $conn->prepare("SELECT title, meeting_date, reminder_time FROM meetings WHERE user_id = ? ORDER BY meeting_date ASC");

// Saista lietotāja ID parametru vaicājumam
$stmt->bind_param("i", $user_id);

// Izpilda vaicājumu
$stmt->execute();

// Saņem rezultātu kopu
$result = $stmt->get_result();

// Inicializē tukšu masīvu tikšanās ierakstiem
$meetings = [];

// Ciklā pa vienam ierakstam ievieto tos masīvā
while ($row = $result->fetch_assoc()) {
    $meetings[] = $row;
}

// Aizver sagatavoto vaicājumu
$stmt->close();
// Aizver datubāzes savienojumu
$conn->close();

// Nosaka atbildes galveni kā JSON formātu
header("Content-Type: application/json");

// Izvada tikšanās datus JSON formātā
echo json_encode($meetings);
?>
