<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once __DIR__ . '/db.php';
session_start();

header('Content-Type: application/json');

if (!isset($conn) || $conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed', 'message' => $conn->connect_error ?? 'Connection not established']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Only POST requests allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$title = trim($input['title'] ?? '');
$event_date = trim($input['date'] ?? '');

if (empty($title) || empty($event_date)) {
    http_response_code(400);
    echo json_encode(['error' => 'Title and date are required']);
    exit;
}

try {
    $checkStmt = $conn->prepare("SELECT id FROM events WHERE title = ? AND Event_date = ?");
    if (!$checkStmt) throw new Exception("Prepare failed: " . $conn->error);
    $checkStmt->bind_param("ss", $title, $event_date);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        echo json_encode(['success' => false, 'error' => 'Duplicate event already exists']);
        $checkStmt->close();
        exit;
    }
    $checkStmt->close();

    $stmt = $conn->prepare("INSERT INTO events (title, Event_date, created_at) VALUES (?, ?, NOW())");
    if (!$stmt) throw new Exception("Prepare failed: " . $conn->error);
    $stmt->bind_param("ss", $title, $event_date);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'event' => [
                'id' => $conn->insert_id,
                'title' => $title,
                'Event_date' => $event_date,
                'created_at' => date('Y-m-d H:i:s')
            ]
        ]);
    } else {
        throw new Exception($stmt->error);
    }
    $stmt->close();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
} finally {
    if (isset($conn)) $conn->close();
}
?>
