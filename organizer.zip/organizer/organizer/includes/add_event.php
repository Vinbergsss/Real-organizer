<?php
// Iespējo visu kļūdu ziņošanu
error_reporting(E_ALL);
// Uzstāda, lai kļūdas tiktu rādītas ekrānā
ini_set('display_errors', 1);

// Iekļauj datubāzes savienojuma failu
require_once __DIR__ . '/db.php';

// Sāk sesiju
session_start();

// Pārbauda, vai datubāzes savienojums ir izveidots veiksmīgi
if (!isset($conn) || $conn->connect_error) {
    // Ja nav, nosūta 500 kļūdas kodu un atgriež kļūdas ziņojumu JSON formātā
    header("HTTP/1.1 500 Internal Server Error");
    die(json_encode([
        'error' => 'Database connection failed',
        'message' => isset($conn) ? $conn->connect_error : 'Connection not established'
    ]));
}

// Atļauj tikai POST pieprasījumus
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Ja pieprasījums nav POST, nosūta 405 kļūdas kodu un kļūdas ziņojumu JSON formātā
    header("HTTP/1.1 405 Method Not Allowed");
    die(json_encode(['error' => 'Only POST requests allowed']));
}

// Saņem un validē ievaddatus - mēģina iegūt datus no JSON ķermeņa vai POST datiem
$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
// Noslauka tukšumus no virsraksta un datuma
$title = trim($input['title'] ?? '');
$event_date = trim($input['date'] ?? '');

// Pārbauda, vai virsraksts un datums nav tukši
if (empty($title) || empty($event_date)) {
    // Ja kāds no laukiem ir tukšs, nosūta 400 kļūdas kodu un kļūdas ziņojumu
    header("HTTP/1.1 400 Bad Request");
    die(json_encode(['error' => 'Title and date are required']));
}

try {
    // Sagatavo SQL vaicājumu, lai pārbaudītu, vai jau nav pasākuma ar tādu pašu virsrakstu un datumu
    $checkStmt = $conn->prepare("SELECT id FROM events WHERE title = ? AND Event_date = ?");
    if (!$checkStmt) {
        // Ja vaicājuma sagatavošana neizdodas, izmētā izņēmumu ar kļūdas ziņojumu
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Piesaista parametrus sagatavotajam vaicājumam
    $checkStmt->bind_param("ss", $title, $event_date);
    // Izpilda vaicājumu
    $checkStmt->execute();
    // Saglabā rezultātus, lai varētu pārbaudīt rindu skaitu
    $checkStmt->store_result();

    // Ja atrasts kāds pasākums ar tādiem pašiem datiem
    if ($checkStmt->num_rows > 0) {
        // Atgriež ziņojumu, ka tāds pasākums jau eksistē, un pārtrauc izpildi
        echo json_encode(['success' => false, 'error' => 'Duplicate event already exists']);
        $checkStmt->close();
        exit;
    }
    $checkStmt->close();

    // Sagatavo SQL vaicājumu jauna pasākuma ievietošanai datubāzē
    $stmt = $conn->prepare("INSERT INTO events (title, Event_date, created_at) VALUES (?, ?, NOW())");
    if (!$stmt) {
        // Ja sagatavošana neizdodas, izmētā izņēmumu
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Piesaista parametrus jauna pasākuma ievietošanai
    $stmt->bind_param("ss", $title, $event_date);

    // Izpilda vaicājumu
    if ($stmt->execute()) {
        // Ja ievietošana veiksmīga, atgriež veiksmīgu atbildi ar jaunā pasākuma datiem JSON formātā
        echo json_encode([
            'success' => true,
            'event' => [
                'id' => $conn->insert_id,
                'title' => $title,
                'Event_date' => $event_date,
                'created_at' => date('Y-m-d H:i:s')
            ]
        ]);
    } else {
        // Ja kļūda vaicājuma izpildē, izmētā izņēmumu ar kļūdas tekstu
        throw new Exception($stmt->error);
    }

    $stmt->close();
} catch (Exception $e) {
    // Apstrādā izņēmumu - nosūta 500 kļūdas kodu un atgriež kļūdas ziņojumu JSON formātā
    header("HTTP/1.1 500 Internal Server Error");
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
} finally {
    // Noslēdz datubāzes savienojumu, ja tas ir atvērts
    if (isset($conn)) {
        $conn->close();
    }
}
?>
