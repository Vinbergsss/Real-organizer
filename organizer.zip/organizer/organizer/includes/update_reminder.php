<?php
session_start();
require_once 'db.php';
global $conn;

header("Content-Type: application/json");

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id']) || !is_numeric($input['id'])) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Invalid ID']));
}

try {
    $stmt = $conn->prepare("UPDATE reminders SET status = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param("sii", $input['status'], $input['id'], $_SESSION['user_id']);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        throw new Exception($stmt->error);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>