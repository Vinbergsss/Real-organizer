<?php
session_start();  // Sāk sesiju
require_once 'db.php';  // Iekļauj datubāzes savienojumu

global $conn;  // Padara $conn globālu

header("Content-Type: application/json");  // Nosaka atbildes tipu kā JSON

// Pārbauda, vai datubāzes savienojums ir aktīvs un nav kļūdu
if (!isset($conn) || $conn->connect_error) {
    http_response_code(500);
    die(json_encode(['error' => 'Database connection failed']));
}

// Pārbauda, vai lietotājs ir ielogojies
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode(['error' => 'Not logged in']));
}

try {
    // Sagatavo SQL vaicājumu: atlasīt atgādinājumus kopā ar saistīto notikuma nosaukumu (ja ir)
    $stmt = $conn->prepare("
        SELECT r.*, e.title as event_title 
        FROM reminders r
        LEFT JOIN events e ON r.event_id = e.id
        WHERE r.user_id = ?
        ORDER BY r.reminder_date ASC
    ");

    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Saista parametrus un izpilda vaicājumu
    $stmt->bind_param("i", $_SESSION['user_id']);
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    // Saņem rezultātus un sagatavo atbildi
    $result = $stmt->get_result();
    $reminders = [];

    while ($row = $result->fetch_assoc()) {
        $reminders[] = $row;
    }

    echo json_encode($reminders);  // Atgriež atgādinājumus JSON formātā

} catch (Exception $e) {
    // Kļūdas gadījumā atgriež kļūdas ziņojumu un izsaukumu steku
    http_response_code(500);
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
} finally {
    // Atbrīvo resursus
    if (isset($stmt)) $stmt->close();
    if (isset($conn)) $conn->close();
}
?>
