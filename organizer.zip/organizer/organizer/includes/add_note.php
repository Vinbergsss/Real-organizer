<?php
// Sāk sesiju, lai varētu strādāt ar lietotāja sesijas datiem
session_start();
// Iekļauj datubāzes savienojuma failu
require 'db.php';

// Uzstāda atbildes galveni, ka atbilde būs JSON formātā
header("Content-Type: application/json");

// Pārbauda, vai datubāzes savienojums ir izveidots veiksmīgi
if (!isset($conn) || $conn->connect_error) {
    // Ja nav, nosūta 500 kļūdas kodu un atgriež JSON ar kļūdu
    http_response_code(500);
    die(json_encode(['success' => false, 'error' => 'Database connection failed']));
}

// Pārbauda, vai lietotājs ir pieslēdzies (vai sesijā ir lietotāja ID)
if (!isset($_SESSION['user_id'])) {
    // Ja nav, nosūta 401 Unauthorized kļūdas kodu un JSON atbildi
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Unauthorized access']));
}

// Saglabā lietotāja ID mainīgajā
$user_id = $_SESSION['user_id'];

// Saņem ievaddatus:
// Mēģina nolasīt JSON ķermeni un pārveidot par masīvu
$input = json_decode(file_get_contents('php://input'), true);
print_r ($input );
// Ja pieprasījums ir POST un JSON nav, ņem datus no parastajiem POST datiem
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($input)) {
    $input = $_POST;
}

// Pārbauda, vai obligātie lauki 'title' un 'content' nav tukši
if (empty($input['title']) || empty($input['content'])) {
    // Ja kāds no laukiem tukšs, atgriež 400 Bad Request kļūdu un JSON paziņojumu
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Title and content are required']));
}

// Attīra un sagatavo datus
$title = trim($input['title']);
$content = trim($input['content']);
// Ja datums nav norādīts, iestata šodienas datumu
$note_date = $input['note_date'] ?? date('Y-m-d');
// Iegūst event_id, ja tāds dots, citādi NULL
$event_id = $input['event_id'] ?? null;

try {
    // Ja event_id ir norādīts, pārbauda, vai tas pieder lietotājam un eksistē
    if (!empty($event_id)) {
        $check_stmt = $conn->prepare("SELECT id FROM events WHERE id = ? AND user_id = ?");
        $check_stmt->bind_param("ii", $event_id, $user_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        // Ja nav atrasts atbilstošs pasākums, atgriež kļūdu
        if ($check_result->num_rows === 0) {
            http_response_code(400);
            die(json_encode(['success' => false, 'error' => 'Invalid event selected']));
        }
        $check_stmt->close();
    } else {
        $event_id = null; // Nodrošina, ka datubāzē tiks ielikts NULL
    }

    // Sagatavo vaicājumu, lai ievietotu jaunu piezīmi tabulā "notes"
    $stmt = $conn->prepare("
        INSERT INTO notes (user_id, title, content, note_date, event_id)
        VALUES (?, ?, ?, ?, ?)
    ");

    // Piesaista parametrus (int, string, string, string, int)
    $stmt->bind_param("isssi", $user_id, $title, $content, $note_date, $event_id);

    // Izpilda vaicājumu
    if ($stmt->execute()) {
        // Ja izpilde veiksmīga, atgriež JSON ar veiksmes paziņojumu un jaunās piezīmes ID
        echo json_encode([
            'success' => true,
            'message' => 'Note added successfully',
            'note_id' => $stmt->insert_id
        ]);
    } else {
        // Ja kļūda, izmētā izņēmumu ar kļūdas tekstu
        throw new Exception("Database error: " . $stmt->error);
    }
} catch (Exception $e) {
    // Kļūdas gadījumā atgriež 500 servera kļūdas kodu un kļūdas ziņojumu JSON formātā
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} finally {
    // Noslēdz sagatavotos vaicājumus un datubāzes savienojumu
    if (isset($stmt)) $stmt->close();
    if (isset($check_stmt)) $check_stmt->close();
    $conn->close();
}
?>