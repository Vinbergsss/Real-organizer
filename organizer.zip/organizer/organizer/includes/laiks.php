<?php
include'db.php';
$result = $conn->query("SELECT now() as time");
$row = $result->fetch_assoc();
print_r( $row);
    
?>