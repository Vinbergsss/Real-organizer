<?php
// Include database connection
global $conn;
include 'db.php';

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../html/index.html");
    exit;
}

// Get user data from database
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // User not found in database
    session_destroy();
    header("Location: ../html/index.html");
    exit;
}

$user = $result->fetch_assoc();
$username = htmlspecialchars($user['username']);
$email = htmlspecialchars($user['email']);
$full_name = htmlspecialchars($user['full_name'] ?? '');
$profile_pic = $user['profile_pic'] ?? '../public/images/default-profile.png';
$bio = htmlspecialchars($user['bio'] ?? '');
$created_at = date('F j, Y', strtotime($user['created_at']));

// Handle profile updates
$update_success = false;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $new_full_name = trim($_POST['full_name']);
    $new_bio = trim($_POST['bio']);
    $new_email = trim($_POST['email']);

    // Validate inputs
    if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    if (strlen($new_full_name) > 100) {
        $errors[] = "Full name is too long";
    }

    if (strlen($new_bio) > 500) {
        $errors[] = "Bio is too long (max 500 characters)";
    }

    // Handle profile picture upload
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['profile_pic']['type'];

        if (in_array($file_type, $allowed_types)) {
            $upload_dir = '../public/uploads/profiles/';
            $file_ext = pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION);
            $new_filename = 'user_' . $user_id . '_' . time() . '.' . $file_ext;
            $destination = $upload_dir . $new_filename;

            if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $destination)) {
                // Delete old profile picture if it's not the default
                if ($profile_pic !== '../public/images/default-profile.png' && file_exists($profile_pic)) {
                    unlink($profile_pic);
                }
                $profile_pic = $destination;
            } else {
                $errors[] = "Failed to upload profile picture";
            }
        } else {
            $errors[] = "Only JPG, PNG, and GIF images are allowed";
        }
    }

    // Update database if no errors
    if (empty($errors)) {
        $update_query = "UPDATE users SET full_name = ?, bio = ?, email = ?, profile_pic = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("ssssi", $new_full_name, $new_bio, $new_email, $profile_pic, $user_id);

        if ($update_stmt->execute()) {
            $update_success = true;
            // Refresh user data
            $full_name = htmlspecialchars($new_full_name);
            $bio = htmlspecialchars($new_bio);
            $email = htmlspecialchars($new_email);
        } else {
            $errors[] = "Failed to update profile";
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Verify current password
    $password_query = "SELECT password FROM users WHERE id = ?";
    $password_stmt = $conn->prepare($password_query);
    $password_stmt->bind_param("i", $user_id);
    $password_stmt->execute();
    $password_result = $password_stmt->get_result();
    $db_password = $password_result->fetch_assoc()['password'];

    if (!password_verify($current_password, $db_password)) {
        $errors[] = "Current password is incorrect";
    } elseif ($new_password !== $confirm_password) {
        $errors[] = "New passwords don't match";
    } elseif (strlen($new_password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    } else {
        // Update password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_password_query = "UPDATE users SET password = ? WHERE id = ?";
        $update_password_stmt = $conn->prepare($update_password_query);
        $update_password_stmt->bind_param("si", $hashed_password, $user_id);

        if ($update_password_stmt->execute()) {
            $update_success = true;
        } else {
            $errors[] = "Failed to update password";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Organizer</title>
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Main styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f5f5f5;
        }

        header {
            background-color: #6200ea;
            color: white;
            padding: 1rem 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        nav ul {
            display: flex;
            justify-content: center;
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav li {
            margin: 0 1rem;
        }

        nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        nav a:hover, nav a.active {
            background-color: rgba(255,255,255,0.2);
        }

        /* Profile container */
        .profile-container {
            max-width: 800px;
            margin: 2rem auto;
            background: #fff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .profile-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .profile-header h2 {
            font-size: 2rem;
            color: #6200ea;
            margin-bottom: 0.5rem;
        }

        .profile-header p {
            color: #666;
        }

        /* Profile content */
        .profile-content {
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .profile-sidebar {
            flex: 1;
            min-width: 250px;
        }

        .profile-main {
            flex: 2;
            min-width: 300px;
        }

        /* Profile picture */
        .profile-pic-container {
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .profile-pic {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #6200ea;
            margin-bottom: 1rem;
        }

        /* Profile details */
        .profile-details {
            margin-bottom: 2rem;
        }

        .profile-details h3 {
            color: #6200ea;
            margin-bottom: 1rem;
            border-bottom: 1px solid #eee;
            padding-bottom: 0.5rem;
        }

        .detail-item {
            display: flex;
            margin-bottom: 1rem;
        }

        .detail-label {
            font-weight: bold;
            min-width: 120px;
            color: #555;
        }

        .detail-value {
            flex: 1;
        }

        /* Stats */
        .profile-stats {
            display: flex;
            justify-content: space-around;
            text-align: center;
            margin: 2rem 0;
            padding: 1rem;
            background: #f9f9f9;
            border-radius: 8px;
        }

        .stat-item {
            padding: 0 1rem;
        }

        .stat-number {
            font-size: 1.5rem;
            font-weight: bold;
            color: #6200ea;
        }

        .stat-label {
            font-size: 0.9rem;
            color: #666;
        }

        /* Buttons */
        .btn {
            display: inline-block;
            padding: 0.8rem 1.5rem;
            font-size: 1rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            text-decoration: none;
        }

        .btn-primary {
            background-color: #6200ea;
            color: #fff;
        }

        .btn-primary:hover {
            background-color: #3700b3;
            transform: translateY(-2px);
        }

        .btn-danger {
            background-color: #d32f2f;
            color: #fff;
        }

        .btn-danger:hover {
            background-color: #b71c1c;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background-color: #757575;
            color: #fff;
        }

        .btn-secondary:hover {
            background-color: #616161;
            transform: translateY(-2px);
        }

        .btn-group {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }

        /* Forms */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: #555;
        }

        .form-control {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        .form-control:focus {
            border-color: #6200ea;
            outline: none;
            box-shadow: 0 0 0 2px rgba(98, 0, 234, 0.2);
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        /* Tabs */
        .tabs {
            display: flex;
            border-bottom: 1px solid #ddd;
            margin-bottom: 1.5rem;
        }

        .tab {
            padding: 0.8rem 1.5rem;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
        }

        .tab.active {
            border-bottom-color: #6200ea;
            color: #6200ea;
            font-weight: bold;
        }

        .tab:hover:not(.active) {
            background-color: #f5f5f5;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Alerts */
        .alert {
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1.5rem;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .profile-content {
                flex-direction: column;
            }

            .profile-stats {
                flex-direction: column;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
<header>
    <nav>
        <ul>
            <li><a href="../public/html/main.html">Home</a></li>
            <li><a href="../public/html/calendar.html">Calendar</a></li>
            <li><a href="../includes/profile.php" class="active">Profile</a></li>
            <li><a href="../includes/logout.php">Logout</a></li>
        </ul>
    </nav>
</header>

<main>
    <div class="profile-container">
        <!-- Success/error messages -->
        <?php if ($update_success): ?>
            <div class="alert alert-success">
                Profile updated successfully!
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo htmlspecialchars($error); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="profile-header">
            <h2>Your Profile</h2>
            <p>Manage your account settings and personal information</p>
        </div>

        <div class="tabs">
            <div class="tab active" data-tab="overview">Overview</div>
            <div class="tab" data-tab="edit-profile">Edit Profile</div>
            <div class="tab" data-tab="change-password">Change Password</div>
        </div>

        <!-- Overview Tab -->
        <div class="tab-content active" id="overview">
            <div class="profile-content">
                <div class="profile-sidebar">
                    <div class="profile-pic-container">
                        <img src="<?php echo htmlspecialchars($profile_pic); ?>" alt="Profile Picture" class="profile-pic">
                    </div>

                    <div class="profile-stats">
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $created_at; ?></div>
                            <div class="stat-label">Member Since</div>
                        </div>
                    </div>

                    <div class="profile-details">
                        <h3>Account Info</h3>
                        <div class="detail-item">
                            <div class="detail-label">Username:</div>
                            <div class="detail-value"><?php echo $username; ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Email:</div>
                            <div class="detail-value"><?php echo $email; ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Joined:</div>
                            <div class="detail-value"><?php echo $created_at; ?></div>
                        </div>
                    </div>
                </div>

                <div class="profile-main">
                    <div class="profile-details">
                        <h3>Personal Information</h3>
                        <div class="detail-item">
                            <div class="detail-label">Full Name:</div>
                            <div class="detail-value"><?php echo $full_name ?: 'Not set'; ?></div>
                        </div>
                    </div>

                    <div class="profile-details">
                        <h3>About Me</h3>
                        <p><?php echo $bio ?: 'No bio yet.'; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Profile Tab -->
        <div class="tab-content" id="edit-profile">
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="profile_pic" class="form-label">Profile Picture</label>
                    <div style="display: flex; align-items: center; gap: 1rem;">
                        <img src="<?php echo htmlspecialchars($profile_pic); ?>" alt="Current Profile" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover;">
                        <input type="file" id="profile_pic" name="profile_pic" class="form-control" accept="image/*">
                    </div>
                </div>

                <div class="form-group">
                    <label for="full_name" class="form-label">Full Name</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" value="<?php echo htmlspecialchars($full_name); ?>">
                </div>

                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>

                <div class="form-group">
                    <label for="bio" class="form-label">Bio</label>
                    <textarea id="bio" name="bio" class="form-control"><?php echo htmlspecialchars($bio); ?></textarea>
                </div>

                <div class="btn-group">
                    <button type="submit" name="update_profile" class="btn btn-primary">Save Changes</button>
                    <button type="button" class="btn btn-secondary" onclick="switchTab('overview')">Cancel</button>
                </div>
            </form>
        </div>

        <!-- Change Password Tab -->
        <div class="tab-content" id="change-password">
            <form action="" method="POST">
                <div class="form-group">
                    <label for="current_password" class="form-label">Current Password</label>
                    <input type="password" id="current_password" name="current_password" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="new_password" class="form-label">New Password</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" required>
                    <small class="form-text">Minimum 8 characters</small>
                </div>

                <div class="form-group">
                    <label for="confirm_password" class="form-label">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                </div>

                <div class="btn-group">
                    <button type="submit" name="change_password" class="btn btn-primary">Change Password</button>
                    <button type="button" class="btn btn-secondary" onclick="switchTab('overview')">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</main>

<footer>
    <p>&copy; 2025 Organizer. All rights reserved.</p>
</footer>

<script>
    // Tab switching functionality
    function switchTab(tabId) {
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });

        // Deactivate all tabs
        document.querySelectorAll('.tab').forEach(tab => {
            tab.classList.remove('active');
        });

        // Activate selected tab
        document.getElementById(tabId).classList.add('active');
        document.querySelector(`.tab[data-tab="${tabId}"]`).classList.add('active');
    }

    // Add click event listeners to tabs
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function() {
            switchTab(this.getAttribute('data-tab'));
        });
    });
</script>
</body>
</html>