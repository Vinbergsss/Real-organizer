<?php
// Sāk sesiju, lai piekļūtu sesijas mainīgajiem (piemēram, user_id)
session_start();
// Iekļauj datubāzes savienojuma failu
require_once 'db.php';

// Nodrošina, ka datubāzes savienojums ir globāli pieejams
global $conn;

// Nosaka atbildes saturu kā JSON
header("Content-Type: application/json");

// 1. Pārbauda, vai datubāzes savienojums ir derīgs un ir mysqli objekts
if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500); // Servera kļūda
    die(json_encode(['success' => false, 'error' => 'Database connection failed']));
}

// 2. Pārbauda, vai lietotājs ir autorizējies (ir user_id sesijā)
if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Nav autorizēts
    die(json_encode(['success' => false, 'error' => 'Authentication required']));
}

// 3. Nolasa ienākošos JSON datus un pārbauda, vai ir definēts un derīgs 'id' lauks
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id']) || !is_numeric($input['id'])) {
    http_response_code(400); // Nepareizi dati
    die(json_encode(['success' => false, 'error' => 'Invalid reminder ID']));
}

// Pārvērš ID par veselu skaitli un saglabā sesijas lietotāja ID
$reminder_id = (int)$input['id'];
$user_id = $_SESSION['user_id'];

try {
    // 4. Sagatavo DELETE vaicājumu, lai dzēstu atgādinājumu pēc ID un lietotāja ID (drošībai)
    $stmt = $conn->prepare("DELETE FROM reminders WHERE id = ? AND user_id = ?");

    if (!$stmt) {
        // Ja sagatavošana neizdodas, met izņēmumu ar kļūdas ziņojumu
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Saista parametrus vaicājumam (divi veseli skaitļi)
    $stmt->bind_param("ii", $reminder_id, $user_id);

    // Izpilda vaicājumu
    if ($stmt->execute()) {
        // Atgriež JSON atbildi ar veiksmīgu dzēšanu un vai kaut kas tika dzēsts (affected_rows > 0)
        echo json_encode([
            'success' => true,
            'deleted' => $stmt->affected_rows > 0
        ]);
    } else {
        // Ja izpilde neizdodas, met izņēmumu ar kļūdas ziņojumu
        throw new Exception($stmt->error);
    }
} catch (Exception $e) {
    // Ja notiek jebkāda kļūda, atgriež 500 servera kļūdu un kļūdas ziņojumu JSON formātā
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} finally {
    // 5. Pārliecinās, ka sagatavotais vaicājums tiek aizvērts un datubāzes savienojums slēgts
    if (isset($stmt)) $stmt->close();
    $conn->close();
}
?>
