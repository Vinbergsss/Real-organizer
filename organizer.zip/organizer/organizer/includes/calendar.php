<?php
// Faila pašā augšā iestata atbildes galveni — norāda, ka atbilde būs JSON formātā
header("Content-Type: application/json");

// Iespējo visu kļūdu ziņošanu, bet neizvada tās tieši ekrānā, tikai reģistrē (log)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Iekļauj datubāzes savienojuma failu
require_once 'db.php';

try {
    // Nolasa POST ķermeni kā JSON un dekodē to uz asociatīvu masīvu
    $input = json_decode(file_get_contents('php://input'), true);

    // Pārbauda, vai JSON dekodēšana izdevās
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("Invalid JSON input");  // Ja nē, met izņēmumu
    }

    // Apstrādā dzēšanas (DELETE) pieprasījumus — ja saņemts 'delete' un 'id'
    if (isset($input['delete']) && isset($input['id'])) {
        $id = (int)$input['id'];  // Pārvērš id par veselu skaitli

        // Sagatavo SQL vaicājumu, lai dzēstu ierakstu tabulā "events"
        $stmt = $conn->prepare("DELETE FROM events WHERE id = ?");
        $stmt->bind_param("i", $id);

        // Izpilda vaicājumu un pārbauda rezultātu
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);  // Veiksmes gadījumā atbild ar success = true
        } else {
            throw new Exception("Database deletion failed");  // Pretējā gadījumā met kļūdu
        }

        $stmt->close();
        exit;  // Pārtrauc skripta izpildi
    }

    // Apstrādā pieprasījumus, lai pievienotu jaunu notikumu (ja ir 'date' un 'title')
    if (isset($input['date']) && isset($input['title'])) {
        $date = $input['date'];
        $title = $input['title'];

        // Sagatavo SQL vaicājumu jauna notikuma pievienošanai
        $stmt = $conn->prepare("INSERT INTO events (event_date, title) VALUES (?, ?)");
        $stmt->bind_param("ss", $date, $title);

        // Izpilda vaicājumu
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);  // Veiksmes gadījumā atbild ar success = true
        } else {
            throw new Exception("Failed to add event");  // Pretējā gadījumā met kļūdu
        }

        $stmt->close();
        exit;  // Pārtrauc skripta izpildi
    }

    // Ja nav atpazīts neviens pieprasījums, met kļūdu par nederīgu pieprasījumu
    throw new Exception("Invalid request");

} catch (Exception $e) {
    // Noķer visas kļūdas, nosūta HTTP 500 statusu un kļūdas ziņojumu JSON formātā
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
    exit;
}
