<?php
session_start();
require_once 'db.php';

header("Content-Type: application/json");

// Pārbauda savienojumu ar datubāzi
if (!isset($conn) || $conn->connect_error) {
    http_response_code(500);
    die(json_encode(['success' => false, 'error' => 'Database connection failed']));
}

// Pārbauda lietotāju
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Not logged in']));
}

error_log("Received POST data: " . print_r($_POST, true));


$required_fields = [
    'event_id' => 'Event ID',
    'reminder_date' => 'Reminder Date'
];

foreach ($required_fields as $field => $label) {
    if (empty($_POST[$field])) {
        http_response_code(400);
        die(json_encode([
            'success' => false,
            'error' => "Missing required field: $label",
            'received_data' => $_POST  // For debugging
        ]));
    }
}

// Apstrādā datus
try {
    $user_id = $_SESSION['user_id'];
    $event_id = (int)$_POST['event_id'];
    $reminder_date_input = $_POST['reminder_date'];
    $status = 'pending';

    // Pārveido formātu
    $reminder_date = DateTime::createFromFormat('Y-m-d\TH:i', $reminder_date_input);
    if (!$reminder_date) {
        throw new Exception("Invalid date format. Please use YYYY-MM-DDTHH:MM format");
    }
    $formatted_date = $reminder_date->format('Y-m-d H:i:s');

    // Ievieto datubāzē
    $stmt = $conn->prepare("INSERT INTO reminders 
                          (user_id, event_id, reminder_date, status) 
                          VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $user_id, $event_id, $formatted_date, $status);

    if ($stmt->execute()) {

        $reminder_id = $conn->insert_id;
        $stmt->close();


        $stmt = $conn->prepare("SELECT * FROM reminders WHERE id = ?");
        $stmt->bind_param("i", $reminder_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $new_reminder = $result->fetch_assoc();

        echo json_encode([
            'success' => true,
            'reminder' => $new_reminder,
            'debug' => [
                'input_date' => $reminder_date_input,
                'formatted_date' => $formatted_date
            ]
        ]);
    } else {
        throw new Exception("Database error: " . $stmt->error);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'debug' => [
            'post_data' => $_POST,
            'backtrace' => $e->getTraceAsString()
        ]
    ]);
} finally {
    if (isset($conn)) $conn->close();
}
?>